我的｜月經小日記 v4

請使用 ZIP 裡面的 index.html 上傳到 GitHub。
這一版修正日期顯示/排序可能差一天的問題，並保留原本的經期紀錄、修改、刪除、月曆、統計功能。
localStorage 資料鍵仍為 my_period_records_v1。
